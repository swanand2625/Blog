import java.util.ArrayList;
import java.util.Scanner;

public class A10Q1 {
    public static void solve(int col, int[] queens, ArrayList<int[]> ans, int[] leftrow, int[] upperDiagonal, int[] lowerDiagonal, int n) {
        if (col == n) {
            ans.add(queens.clone()); 
            return;
        }
        for (int row = 0; row < n; row++) {
            if (leftrow[row] == 0 && lowerDiagonal[row + col] == 0 && upperDiagonal[n - 1 + col - row] == 0) {
                queens[row] = col;
                leftrow[row] = 1;
                lowerDiagonal[row + col] = 1;
                upperDiagonal[n - 1 + col - row] = 1;
                solve(col + 1, queens, ans, leftrow, upperDiagonal, lowerDiagonal, n);
                leftrow[row] = 0;
                lowerDiagonal[row + col] = 0;
                upperDiagonal[n - 1 + col - row] = 0;
            }
        }
    }

    public static ArrayList<int[]> solveNQueens(int n) {
        ArrayList<int[]> ans = new ArrayList<>();
        int[] queens = new int[n];
        int[] leftrow = new int[n];
        int[] upperDiagonal = new int[2 * n - 1];
        int[] lowerDiagonal = new int[2 * n - 1];
        solve(0, queens, ans, leftrow, upperDiagonal, lowerDiagonal, n);
        return ans;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the value of n: ");
        int n = sc.nextInt();
        ArrayList<int[]> ans = solveNQueens(n);

        for (int i = 0; i < ans.size(); i++) {
            System.out.println("Arrangement " + (i + 1));
            for (int j = 0; j < n; j++) {
                System.out.print((ans.get(i)[j] + 1) + " ");
            }
            System.out.println();
        }

        sc.close();
    }
}