import java.util.ArrayList;
import java.util.List;

class A10Q2 
{
    public void solve(int col, List<String> board, List<List<String>> ans, int[] leftrow, int[] upperDiagonal, int[] lowerDiagonal, int n) {
        if (col == n) {
            ans.add(new ArrayList<>(board)); 
            return;
        }
        for (int row = 0; row < n; row++) {
            if (leftrow[row] == 0 && lowerDiagonal[row + col] == 0 && upperDiagonal[n - 1 + col - row] == 0) {
                char[] charArray = board.get(row).toCharArray();
                charArray[col] = 'Q';
                board.set(row, new String(charArray));
                
                leftrow[row] = 1;
                lowerDiagonal[row + col] = 1;
                upperDiagonal[n - 1 + col - row] = 1;

                solve(col + 1, board, ans, leftrow, upperDiagonal, lowerDiagonal, n);

                charArray[col] = 'x';
                board.set(row, new String(charArray));
                
                leftrow[row] = 0;
                lowerDiagonal[row + col] = 0;
                upperDiagonal[n - 1 + col - row] = 0;
            }
        }
    }

    public List<List<String>> solveNQueens(int n) {
        List<List<String>> ans = new ArrayList<>();
        List<String> board = new ArrayList<>();
        String s = "x".repeat(n);
        
        for (int i = 0; i < n; i++) {
            board.add(s);
        }
        
        int[] leftrow = new int[n];
        int[] upperDiagonal = new int[2 * n - 1];
        int[] lowerDiagonal = new int[2 * n - 1];
        
        solve(0, board, ans, leftrow, upperDiagonal, lowerDiagonal, n);
        return ans;
    }

    public static void main(String[] args) {
        int n = 4; // Example input
        A10Q2 obj = new A10Q2();
        List<List<String>> ans = obj.solveNQueens(n);
        
        for (int i = 0; i < ans.size(); i++) {
            System.out.println("Arrangement " + (i + 1));
            for (String row : ans.get(i)) {
                System.out.println(row);
            }
            System.out.println();
        }
    }
}
