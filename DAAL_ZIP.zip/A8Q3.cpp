#include<bits/stdc++.h>
using namespace std;

int main() 
{
    int N;
    cin >> N;
    
    vector<vector<int>> grid(2, vector<int>(N));
    
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < N; j++) {
            cin >> grid[i][j];
        }
    }

    vector<int> dp(N + 1, 0);

    for (int i = 1; i < N; i++) 
    {
        int option1 = abs(grid[0][i] - grid[0][i - 1]) + abs(grid[1][i] - grid[1][i - 1]);
        int option2 = abs(grid[0][i] - grid[1][i]) + abs(grid[1][i] - grid[0][i]);

        dp[i] = max(dp[i - 1], max(option1, option2));
    }

    cout << dp[N-1] << endl;
    return 0;
}
