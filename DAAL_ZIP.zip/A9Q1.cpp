#include <bits/stdc++.h>
using namespace std;

#define int long long
const int MOD = 1000000007;
const int N = 200022;

int n, parent[N], size[N], sum[N];

int find(int x) {
    if (parent[x] != x) {
        parent[x] = find(parent[x]);
    }
    return parent[x];
}

void unite(int x, int y) {
    int rootX = find(x);
    int rootY = find(y);
    if (rootX != rootY) {
        parent[rootY] = rootX;
        size[rootX] += size[rootY];
        sum[rootX] = (sum[rootX] + sum[rootY]) % MOD;
    }
}

void init() {
    for (int i = 1; i <= n; i++) {
        parent[i] = i;
        size[i] = 1;
        sum[i] = i;
    }
}
void solve() {
    cin >> n;
    init();
    
    vector<pair<int, pair<int, int>>> edges;
    for (int i = 1; i < n; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back({w, {u, v}});
    }
    
    sort(edges.begin(), edges.end());
    int totalCost = 0;
    
    for (const auto& edge : edges) {
        int weight = edge.first;
        int u = edge.second.first;
        int v = edge.second.second;
        
        int mul = (sum[find(u)] * sum[find(v)]) % MOD;
        totalCost = (totalCost + (weight * mul) % MOD) % MOD;
        
        unite(u, v);
    }
    
    cout << totalCost << '\n';
}

signed main() {
    
    solve();
    return 0;
}
