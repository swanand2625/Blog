#include <bits/stdc++.h>
#define int long long
using namespace std;

const int N = 2e5 + 1;
bool prime[N];

void sieve()
{
    memset(prime, true, sizeof(prime));
    prime[0] = prime[1] = false;

    for (int i = 2; i * i < N; i++)
    {
        if (prime[i])
        {
            for (int j = i * i; j < N; j += i)
                prime[j] = false;
        }
    }
}

int32_t main()
{
    sieve();

    int n, m;
    cin >> n >> m;

    vector<pair<int, int>> adj[n + 1];
    vector<int> distance(n + 1, LLONG_MAX);

    for (int i = 0; i < m; i++)
    {
        int x, y;
        cin >> x >> y;
        adj[x].emplace_back(y, max(x, y));
        adj[y].emplace_back(x, max(x, y));
    }

    set<pair<int, int>> pq;

    for (int i = 1; i <= n; i++)
    {
        if (prime[i])
        {
            distance[i] = 0;
            pq.insert({0, i});
        }
    }

    while (!pq.empty())
    {
        auto p = *pq.begin();
        int currDist = p.first, u = p.second;
        
        pq.erase(pq.begin());

        for (auto edge : adj[u])
        {
            int v = edge.first, w = edge.second;
            if (distance[v] > currDist + w)
            {
                pq.erase({distance[v], v});
                distance[v] = currDist + w;
                pq.insert({distance[v], v});
            }
        }
    }

    for (int i = 1; i <= n; i++)
    {
        if (distance[i] == LLONG_MAX)
            cout << -1 << " ";
        else
            cout << distance[i] << " ";
    }
}
