#include <iostream>
#include <vector>
using namespace std;

class DSU {
public:
    vector<int> parent, rank;
    
    DSU(int n) {
        parent.resize(n);
        rank.resize(n, 0);
        for (int i = 0; i < n; i++) {
            parent[i] = i;
        }
    }
    
    int find(int x) {
        if (parent[x] != x) {
            parent[x] = find(parent[x]);  
        }
        return parent[x];
    }
    
    bool unite(int x, int y) {
        int rootX = find(x);
        int rootY = find(y);
        
        if (rootX != rootY) {
            if (rank[rootX] > rank[rootY]) {
                parent[rootY] = rootX;
            } else if (rank[rootX] < rank[rootY]) {
                parent[rootX] = rootY;
            } else {
                parent[rootY] = rootX;
                rank[rootX]++;
            }
            return true;
        }
        return false;
    }
};

int main() {
    int N, M;
    cin >> N >> M;
    
    vector<vector<int>> roads(M, vector<int>(3));
    for (int i = 0; i < M; i++) {
        cin >> roads[i][0] >> roads[i][1] >> roads[i][2];
        roads[i][0]--;  
        roads[i][1]--; 
    }
    
    DSU menDSU(N), womenDSU(N);
    int usedRoads = 0;
    
    for (int i = 0; i < M; i++) {
        if (roads[i][2] == 3) {
            if (menDSU.unite(roads[i][0], roads[i][1]) | womenDSU.unite(roads[i][0], roads[i][1])) {
                usedRoads++;
            }
        }
    }
    
    for (int i = 0; i < M; i++) {
        if (roads[i][2] == 1) {
            if (menDSU.unite(roads[i][0], roads[i][1])) {
                usedRoads++;
            }
        }
    }
    
    for (int i = 0; i < M; i++) {
        if (roads[i][2] == 2) {
            if (womenDSU.unite(roads[i][0], roads[i][1])) {
                usedRoads++;
            }
        }
    }
    
    bool menConnected = true, womenConnected = true;
    for (int i = 1; i < N; i++) {
        if (menDSU.find(i) != menDSU.find(0)) menConnected = false;
        if (womenDSU.find(i) != womenDSU.find(0)) womenConnected = false;
    }
    
    if (menConnected && womenConnected) {
        cout << M - usedRoads << endl; 
    } else {
        cout << -1 << endl; 
}
    return 0;
}
