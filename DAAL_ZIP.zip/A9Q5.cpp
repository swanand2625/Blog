#include<bits/stdc++.h>
using namespace std;

int distanceSquared(int x1, int y1, int x2, int y2) {
    return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
}

int main() {
    int n, d;
    cin >> n >> d;
    
    vector<pair<int, int>> towers(n);
    for (int i = 0; i < n; i++) {
        cin >> towers[i].first >> towers[i].second;
    }

    int d_squared = d * d; 

    vector<unordered_set<int>> adj(n);

    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (distanceSquared(towers[i].first, towers[i].second, towers[j].first, towers[j].second) == d_squared) {
                adj[i].insert(j);
                adj[j].insert(i);
            }
        }
    }

    int towersDestroyed = 0;
    unordered_set<int> destroyed;

    while (true) {
        int maxConnections = 0;
        int towerToRemove = -1;

        for (int i = 0; i < n; i++) {
            if (destroyed.find(i) == destroyed.end() && adj[i].size() > maxConnections) {
                maxConnections = adj[i].size();
                towerToRemove = i;
            }
        }

        if (maxConnections == 0) {
            break;  
        }

        destroyed.insert(towerToRemove);
        towersDestroyed++;

        for (int neighbor : adj[towerToRemove]) {
            adj[neighbor].erase(towerToRemove);
        }
        adj[towerToRemove].clear();
    }

    cout << towersDestroyed << endl;

    return 0;
}
